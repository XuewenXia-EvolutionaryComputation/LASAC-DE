classdef DELaggedReward < handle
    % DE 双因子延迟奖励：近3代滑动平均
    % 1. 最优适应度提升（收敛）
    % 2. 种群多样性提升（探索）
    % 自动归一化 + 自适应权重
    
    properties
        windowSize = 3;     % 近3代
        maximize = false;   % 最小化问题默认
        fitHistory = [];    % 最优适应度历史
        divHistory = [];    % 多样性历史
        maxGen;             % 最大迭代次数（用于自适应权重）
    end
    
    methods
        function obj = DELaggedReward(maxGen, windowSize, maximize)
            if nargin >=1, obj.maxGen = maxGen; end
            if nargin >=2, obj.windowSize = windowSize; end
            if nargin >=3, obj.maximize = maximize; end
        end
        
        % 核心：获取奖励
        function reward = getReward(obj, currentBestFit, population, gen)
            % 计算多样性
            currentDiv = obj.calcDiversity(population);
            
            % 保存历史
            obj.fitHistory = [obj.fitHistory, currentBestFit];
            obj.divHistory = [obj.divHistory, currentDiv];
            
            % 窗口不足时返回小奖励
            if length(obj.fitHistory) <= obj.windowSize
                reward = 0.1 * length(obj.fitHistory);
                return;
            end
            
            % ========== 1. 计算适应度延迟奖励 ==========
            [fitRew] = obj.getFitnessReward();
            
            % ========== 2. 计算多样性延迟奖励 ==========
            [divRew] = obj.getDiversityReward();
            
            % ========== 3. 自适应权重（关键） ==========
            % wFit = gen / obj.maxGen;        % 后期更看重收敛
            wFit = 0.2 + 0.6 * (gen / obj.maxGen);
            wDiv = 1 - wFit;                % 前期更看重探索
            
            % ========== 4. 最终奖励 ==========
            reward = wFit * fitRew + wDiv * divRew;
            reward = max(-1, min(reward, 1)); % 裁剪
            reward = round(reward,4);
        end
        
        % 适应度奖励（近3代滑动平均提升）
        function r = getFitnessReward(obj)
            w = obj.windowSize:-1:1; %w = [3,2,1]; 
            % w = w.^2;          % 新添加
            w = w/sum(w);
          
            win = obj.fitHistory(end-obj.windowSize+1:end);
            prevWin = obj.fitHistory(end-obj.windowSize:end-1);
            % prevWin = obj.fitHistory(end-obj.windowSize);       
            % 此处要重写: 应该是 fitHistory(end-obj.windowSize+1:end) 的 3 个值分别减去 obj.fitHistory(end-obj.windowSize)
            % 得到 3 个差值（或比值）：即 (fit_n+3 - fit_n), (fit_n+2 - fit_n),(fit_n+1 - fit_n)
            % 然后对这 3 个差值进行加权
            
            curr = sum(win.*w);
            prev = sum(prevWin.*w);
            
            if obj.maximize
                imp = (curr+eps)/(prev+eps); %curr - prev;
            else
                imp = (prev+eps)/(curr+eps); %prev - curr;
                % if imp > 10
                %     imp = 10;
                % end
            end
            
            % % 归一化到 [0,1]
            % r = obj.normalize(imp);
            % r = imp;
            r = max(min(log(imp), 1), -1);
        end
        
        % 多样性奖励（提升=正奖励，下降=负奖励）
        function r = getDiversityReward(obj)
            w=obj.windowSize:-1:1; %当 windowSize = 3时，w = [3,2,1]; 
            w = w/sum(w);           
            win = obj.divHistory(end-obj.windowSize+1:end);
            prevWin = obj.divHistory(end-obj.windowSize:end-1);
            
            curr = sum(win.*w);
            prev = sum(prevWin.*w);
            
            % 多样性越高越好
            imp = (curr+eps)/(prev+eps); %curr - prev;
            
            % % 归一化
            % r = obj.normalize(imp);
            r = imp;
        end
        
        % 归一化：把任意提升量映射到 [0,1]
        function n = normalize(obj, x)
            sigma = 0.01;  % 根据你的问题缩放
            n = 1 / (1 + exp(-x / sigma));
        end
        
        % 计算种群多样性（标准DE多样性：种群标准差均值）
        function div = calcDiversity(obj, pop)
            [~, D] = size(pop);
            div = mean(std(pop));  % 所有维度标准差的平均
        end
        
        function reset(obj)
            obj.fitHistory = [];
            obj.divHistory = [];
        end
    end
end
% ========== 核心修改：继承handle类 ==========
classdef ExperienceBuffer < handle
    properties
        capacity;               % 缓冲区容量
        buffer;                 % 经验存储：cell数组
        ptr = 1;                % 写入指针
        current_size = 0;       % 当前存储量（避免和内置size函数冲突）
    end
    
    methods
        function obj = ExperienceBuffer(capacity)
            obj.capacity = capacity;
            % 初始化cell数组存储经验
            obj.buffer = cell(1, capacity);  
            for i = 1:capacity
                obj.buffer{i} = struct('s', [], 'a', [], 'r', [], 's_next', [], 'done', []);
            end
        end
        
        function add(obj, s, a, r, s_next, done)
            % 安全检查：确保输入维度正确
            if isempty(s) || isempty(a) || isempty(r) || isempty(s_next) || isempty(done)
                warning('经验输入包含空值，跳过本次添加');
                return;
            end
            
            % 写入经验到cell数组（直接修改原对象）
            obj.buffer{obj.ptr}.s = s;          
            obj.buffer{obj.ptr}.a = a;          
            obj.buffer{obj.ptr}.r = r;          
            obj.buffer{obj.ptr}.s_next = s_next;
            obj.buffer{obj.ptr}.done = done;    
            
            % 正确累加current_size（直接修改原对象）
            if obj.current_size < obj.capacity
                obj.current_size = obj.current_size + 1;
            end
            
            % 更新指针
            obj.ptr = obj.ptr + 1;
            if obj.ptr > obj.capacity
                obj.ptr = 1;  
            end        
        end
        
        
        function [states, actions, rewards, next_states, dones] = sample(obj, batch_size)
            % 检查采样数量是否合法
            if batch_size > obj.current_size
                error('采样数量(%d)超过缓冲区当前容量(%d)', batch_size, obj.current_size);
            end
        
            % 随机选择采样索引
            sample_idx = randperm(obj.current_size, batch_size);
        
            % 找到第一个非空经验，确定维度（按列向量逻辑）
            valid_idx = find(~cellfun(@isempty, obj.buffer), 1);
            if isempty(valid_idx)
                error('缓冲区无有效经验，无法采样');
            end
            first_exp = obj.buffer{valid_idx};
            
            % ========== 核心：按列向量获取维度（匹配你的8×1 state） ==========
            state_dim = size(first_exp.s, 1);  % 8×1列向量 → 维度=8
            action_dim = size(first_exp.a, 1); % 6×1列向量 → 维度=6
        
            % 初始化输出矩阵（batch_size × 维度，每行是1条经验的行向量）
            states = zeros(batch_size, state_dim);    % batch×8
            actions = zeros(batch_size, action_dim);  % batch×6
            rewards = zeros(batch_size, 1);           % batch×1
            next_states = zeros(batch_size, state_dim);% batch×8
            dones = zeros(batch_size, 1);             % batch×1
        
            % 填充采样数据（核心修复：列向量转置为行向量）
            for i = 1:batch_size
                exp = obj.buffer{sample_idx(i)};
                
                % 1. 状态：8×1列向量 → 转置为1×8行向量，赋值给states(i,:)
                if iscolumn(exp.s)  % 确认是列向量（8×1）
                    states(i, :) = exp.s';  % 转置！关键修复
                else
                    states(i, :) = exp.s;
                end
                
                % 2. 动作：6×1列向量 → 转置为1×6行向量，赋值给actions(i,:)
                if iscolumn(exp.a)
                    actions(i, :) = exp.a';  % 转置！关键修复
                else
                    actions(i, :) = exp.a;
                end
                
                % 3. 奖励/下一状态/done：同理适配
                rewards(i, :) = exp.r;
                if iscolumn(exp.s_next)
                    next_states(i, :) = exp.s_next';
                else
                    next_states(i, :) = exp.s_next;
                end
                dones(i, :) = exp.done;
            end
        end
                

        function sz = size(obj)
            % 返回当前存储量（直接返回原对象的current_size）
            sz = obj.current_size;
        end
        
        % 清空缓冲区（可选）
        function clear(obj)
            obj.ptr = 1;
            obj.current_size = 0;
            for i = 1:obj.capacity
                obj.buffer{i} = struct('s', [], 'a', [], 'r', [], 's_next', [], 'done', []);
            end
        end
    end
end
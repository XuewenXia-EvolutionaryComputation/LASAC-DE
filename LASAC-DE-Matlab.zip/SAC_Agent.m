classdef SAC_Agent < handle
    % --------------- 1. 属性定义（关键：补充q_opt/policy_opt/alpha_opt声明）---------------
    properties
        % 基础参数
        state_dim          % 状态维度（固定为8）
        action_dim         % 动作维度（固定为6：F1/F2/F3/CR1/CR2/CR3）
        F_range            % F的范围 [0.5, 1.0]
        CR_range           % CR的范围 [0.5, 1.0]
        
        % 网络对象
        policy_net         % 策略网络
        q1_net             % Q1网络
        q2_net             % Q2网络
        target_q1_net      % 目标Q1网络
        target_q2_net      % 目标Q2网络
        
        % 优化器状态（结构体）
        policy_opt_state   = [];
        q1_opt_state       = [];
        q2_opt_state       = [];
        alpha_opt_state    = [];
        
        % 超参数（带CB维度标签的dlarray）
        gamma = dlarray(0.99, 'CB');  % 折扣因子
        tau = 0.005;                  % 软更新系数
        alpha = dlarray(0.5, 'CB');   % 熵系数  1.0 -> 0.5
        target_entropy = dlarray(-1, 'CB');  % 目标熵（-action_dim） -6 -> -1
        log_alpha = dlarray(log(1.0), 'CB'); % 温度系数
        
        % 学习率（标量）
        policy_lr = 5e-5;   %1e-4;   % 策略网络学习率
        q_lr = 5e-5;        %1e-4;   % Q网络学习率
        alpha_lr = 1e-4;    %1e-3;   % 温度系数学习率
        
        % ========== 关键修复：声明缺失的优化器选项属性 ==========
        q_opt;              % Q网络Adam优化器选项（结构体）
        policy_opt;         % 策略网络Adam优化器选项（结构体）
        alpha_opt;          % 温度系数Adam优化器选项（结构体）
    end

    % --------------- 2. 方法定义 ---------------
    methods
        %% ========== 构造函数 ==========
        function obj = SAC_Agent(state_dim, action_dim, F_range, CR_range)
            obj.state_dim = state_dim;
            obj.action_dim = action_dim;
            obj.F_range = F_range;
            obj.CR_range = CR_range;
            
            % 1. 创建网络（层命名固定，适配R2025a）
            obj.policy_net = obj.create_policy_net();
            obj.q1_net = obj.create_q_net();
            obj.q2_net = obj.create_q_net();
            
            % 2. 初始化目标网络
            obj.target_q1_net = obj.create_q_net();
            obj.target_q1_net.Learnables = obj.q1_net.Learnables; % 目标网络的权重和偏置初始时是从对应的当前网络中复制过来。而当前网络的相关值是由系统随机给出的
            obj.target_q2_net = obj.create_q_net();
            obj.target_q2_net.Learnables = obj.q2_net.Learnables;
            
            % 3. 手动构造Adam优化器选项（替代adamoptions，兼容所有版本）
            obj.q_opt = struct(...
                'LearningRate', obj.q_lr, ...
                'Beta1', 0.9, ...
                'Beta2', 0.999, ...
                'Epsilon', 1e-8);
            
            obj.policy_opt = struct(...
                'LearningRate', obj.policy_lr, ...
                'Beta1', 0.9, ...
                'Beta2', 0.999, ...
                'Epsilon', 1e-8);
            
            obj.alpha_opt = struct(...
                'LearningRate', obj.alpha_lr, ...
                'Beta1', 0.9, ...
                'Beta2', 0.999, ...
                'Epsilon', 1e-8);
            
            % 4. 初始化优化器状态（调用adaminit）
            obj.q1_opt_state = obj.adaminit(obj.q1_net.Learnables, obj.q_opt);
            obj.q2_opt_state = obj.adaminit(obj.q2_net.Learnables, obj.q_opt);
            obj.policy_opt_state = obj.adaminit(obj.policy_net.Learnables, obj.policy_opt);
            obj.alpha_opt_state = obj.adaminit(obj.log_alpha, obj.alpha_opt);
        end


        %% ========== 网络创建方法 ==========
        function net = create_policy_net(obj)
            layers = [
                featureInputLayer(obj.state_dim, 'Normalization', 'none', 'Name', 'state_input')
                fullyConnectedLayer(64, 'Name', 'policy_fc1')
                reluLayer('Name', 'policy_relu1')
                fullyConnectedLayer(64, 'Name', 'policy_fc2')
                reluLayer('Name', 'policy_relu2')
                fullyConnectedLayer(2*obj.action_dim, 'Name', 'policy_fc_out')
            ];
            net = dlnetwork(layers);
        end

        function net = create_q_net(obj)
            layers = [
                featureInputLayer(obj.state_dim + obj.action_dim, 'Normalization', 'none', 'Name', 'q_input')
                fullyConnectedLayer(64, 'Name', 'q_fc1')
                reluLayer('Name', 'q_relu1')
                fullyConnectedLayer(64, 'Name', 'q_fc2')
                reluLayer('Name', 'q_relu2')
                fullyConnectedLayer(1, 'Name', 'q_fc_out')
            ];
            net = dlnetwork(layers);
        end


        %% ========== 动作生成方法 ==========
        function action = get_exploration_action(obj, state)
            state_dl = dlarray(state, 'CB');
            output = forward(obj.policy_net, state_dl);
            mean = output(1:obj.action_dim, :);
            log_std = output(obj.action_dim+1:end, :);          
            std = exp(log_std);
            epsilon = randn(size(mean), 'like', mean);
            action_dl = mean + std .* epsilon;
            action_dl = tanh(action_dl);
            action = extractdata(action_dl);

           
            F_dim = 3; % 前3维是F（F1/F2/F3）
            CR_dim = obj.action_dim - F_dim; % 后3维是CR（CR1/CR2/CR3）
            
            % tanh输出[-1,1] → 线性变换到[a,b]
            fa = obj.F_range(1:F_dim,1); 
            fb = obj.F_range(1:F_dim,2);
            action(1:F_dim) = ((fb - fa)/2) .* action(1:F_dim) + (fa + fb)/2;     
            action(1:F_dim) = max(min(action(1:F_dim), fb(1:F_dim)), fa(1:F_dim));   % 严格裁剪，避免浮点误差超出范围
            % CR映射：tanh输出[-1,1] → 线性变换到[a,b]
            cra = obj.CR_range(1:F_dim,1); 
            crb = obj.CR_range(1:F_dim,2);
            action(F_dim+1:end) = ((crb-cra)/2) .* action(F_dim+1:end) + (cra+crb)/2;            
            action(F_dim+1:end) = max(min(action(F_dim+1:end), crb(1:F_dim)), cra(1:F_dim)); % 
            
            % 加入微小探索噪声，避免动作同质化
            noise = randn(size(action)) * 0.01;
            action = action + noise;
            % 再次裁剪确保范围有效
            action(1:F_dim) = max(min(action(1:F_dim), fb(1:F_dim)), fa(1:F_dim));
            action(F_dim+1:end) = max(min(action(F_dim+1:end), crb(1:F_dim)), cra(1:F_dim));
        end


        %% ===
        function action = get_action(obj, state)
            state_dl = dlarray(state, 'CB');
            output = forward(obj.policy_net, state_dl);
            mean = output(1:obj.action_dim, :);
            action_dl = tanh(mean);
            action = extractdata(action_dl);            
           
            F_dim = 3; % 前3维是F（F1/F2/F3）
            CR_dim = obj.action_dim - F_dim; % 后3维是CR（CR1/CR2/CR3）
            
            % tanh输出[-1,1] → 线性变换到[a,b]
            fa = obj.F_range(1:F_dim,1); 
            fb = obj.F_range(1:F_dim,2);
            action(1:F_dim) = ((fb - fa)/2) .* action(1:F_dim) + (fa + fb)/2;     
            action(1:F_dim) = max(min(action(1:F_dim), fb(1:F_dim)), fa(1:F_dim));   % 严格裁剪，避免浮点误差超出范围
            % CR映射：tanh输出[-1,1] → 线性变换到[a,b]
            cra = obj.CR_range(1:F_dim,1); 
            crb = obj.CR_range(1:F_dim,2);
            action(F_dim+1:end) = ((crb-cra)/2) .* action(F_dim+1:end) + (cra+crb)/2;            
            action(F_dim+1:end) = max(min(action(F_dim+1:end), crb(1:F_dim)), cra(1:F_dim)); % 
            
            % 加入微小探索噪声，避免动作同质化
            noise = randn(size(action)) * 0.01;
            action = action + noise;
            % 再次裁剪确保范围有效
            action(1:F_dim) = max(min(action(1:F_dim), fb(1:F_dim)), fa(1:F_dim));
            action(F_dim+1:end) = max(min(action(F_dim+1:end), crb(1:F_dim)), cra(1:F_dim));

        end


        %% ========== 核心训练方法（适配手动Adam更新） ==========
        function train(obj, buffer, batch_size)
            % 1. 采样经验
            [states, actions, rewards, next_states, dones] = buffer.sample(batch_size);
            
             % 修复：校验样本是否包含NaN/Inf，有则直接返回
            if any(isnan([states(:); actions(:); rewards(:); next_states(:); dones(:)])) || ...
               any(isinf([states(:); actions(:); rewards(:); next_states(:); dones(:)]))
                warning('经验池采样到NaN/Inf样本，跳过本轮训练');
                return;
            end
            
            % 2. 转换为dlarray（CB格式）
            states = dlarray(states', 'CB');
            actions = dlarray(actions', 'CB');
            rewards = dlarray(rewards', 'CB');
            next_states = dlarray(next_states', 'CB');
            dones = dlarray(dones', 'CB');
            
            % 3. 计算Q网络梯度（dlfeval仅传12个显式参数，无obj）
            [q1_loss, q2_loss, q1_grads, q2_grads] = dlfeval(@obj.calc_q_grads, ...
                obj.q1_net.Learnables, obj.q2_net.Learnables, ...
                obj.target_q1_net.Learnables, obj.target_q2_net.Learnables, ...
                obj.policy_net.Learnables, obj.alpha, obj.gamma, ...
                states, actions, rewards, next_states, dones);
            
            % 校验梯度
            if ~isa(q1_grads, 'table') || isempty(q1_grads.Value)
                warning('Q1梯度无效，跳过更新');
                return;
            end
            
            % 4. 手动Adam更新Q网络（替代内置adamupdate，兼容所有版本）
            [obj.q1_net.Learnables, obj.q1_opt_state] = obj.adam_update_manual(...
                obj.q1_net.Learnables, ...
                q1_grads, ...
                obj.q1_opt_state, ...
                obj.q_lr, ...
                obj.q_opt.Beta1, ...
                obj.q_opt.Beta2, ...
                obj.q_opt.Epsilon);
            
            [obj.q2_net.Learnables, obj.q2_opt_state] = obj.adam_update_manual(...
                obj.q2_net.Learnables, ...
                q2_grads, ...
                obj.q2_opt_state, ...
                obj.q_lr, ...
                obj.q_opt.Beta1, ...
                obj.q_opt.Beta2, ...
                obj.q_opt.Epsilon);
            
            % 5. 软更新目标Q网络
            obj.target_q1_net.Learnables = obj.soft_update(obj.q1_net.Learnables, obj.target_q1_net.Learnables);
            obj.target_q2_net.Learnables = obj.soft_update(obj.q2_net.Learnables, obj.target_q2_net.Learnables);
            
            % 6. 计算策略网络+温度系数梯度
            [policy_loss, alpha_loss, policy_grads, alpha_grads] = dlfeval(@obj.calc_policy_grads, ...
                obj.policy_net.Learnables, obj.q1_net.Learnables, obj.q2_net.Learnables, ...
                obj.log_alpha, obj.alpha, obj.target_entropy, states);
            
            % 校验策略梯度
            if ~isa(policy_grads, 'table') || isempty(policy_grads.Value)
                warning('策略梯度无效，跳过更新');
                return;
            end
            
            % 7. 手动Adam更新策略网络
            [obj.policy_net.Learnables, obj.policy_opt_state] = obj.adam_update_manual(...
                obj.policy_net.Learnables, ...
                policy_grads, ...
                obj.policy_opt_state, ...
                obj.policy_lr, ...
                obj.policy_opt.Beta1, ...
                obj.policy_opt.Beta2, ...
                obj.policy_opt.Epsilon);
            
            % 8. 手动Adam更新温度系数
            [obj.log_alpha, obj.alpha_opt_state] = obj.adam_update_manual(...
                obj.log_alpha, ...
                alpha_grads, ...
                obj.alpha_opt_state, ...
                obj.alpha_lr, ...
                obj.alpha_opt.Beta1, ...
                obj.alpha_opt.Beta2, ...
                obj.alpha_opt.Epsilon);
            obj.alpha = dlarray(exp(extractdata(obj.log_alpha)), 'CB');

             % ========== 新增：α下限约束，保留基础探索能力 ==========
            alpha_min = 0.05; % 最小熵系数，可调
            if obj.alpha < alpha_min
                obj.alpha = dlarray(alpha_min, 'CB');
                obj.log_alpha = dlarray(log(alpha_min), 'CB'); % 同步更新log_alpha
            end
        end

        
        %% ========== 梯度计算方法 ==========
        function [q1_loss, q2_loss, q1_grads, q2_grads] = calc_q_grads(obj, ...
                q1_params, q2_params, target_q1_params, target_q2_params, ...
                policy_params, alpha, gamma, ...
                states, actions, rewards, next_states, dones)
            
            % 1. 重构策略网络
            policy_net = obj.create_policy_net();
            policy_net.Learnables = policy_params;
            
            % 2. 计算下一状态的动作和对数概率
            [next_actions, next_log_probs] = obj.sample_action(policy_net, next_states);
            
            % 3. 拼接Q网络输入
            next_input = [next_states; next_actions];
            
            % 4. 重构目标Q1网络
            target_q1_net = obj.create_q_net();
            target_q1_net.Learnables = target_q1_params;
            target_q1 = forward(target_q1_net, next_input);
            
            % 5. 重构目标Q2网络
            target_q2_net = obj.create_q_net();
            target_q2_net.Learnables = target_q2_params;
            target_q2 = forward(target_q2_net, next_input);
            
            % 6. 计算目标Q值
            target_q = min(target_q1, target_q2) - alpha .* next_log_probs;
            
            % 7. TD目标          
            y = rewards + gamma .* (1 - dones) .* target_q;           
            y = max(min(y, 100), -100);  % 新添加
            
            % 8. 重构当前Q1网络
            q1_net = obj.create_q_net();
            q1_net.Learnables = q1_params;
            current_input = [states; actions];
            q1_pred = forward(q1_net, current_input);
            
            % 9. 重构当前Q2网络
            q2_net = obj.create_q_net();
            q2_net.Learnables = q2_params;
            q2_pred = forward(q2_net, current_input);
            
            % 10. 计算损失
            q1_loss = mse(q1_pred, y);
            q2_loss = mse(q2_pred, y);
            
            % 11. 计算梯度
            q1_grads = dlgradient(q1_loss, q1_params);
            q2_grads = dlgradient(q2_loss, q2_params);
        end


        %% 计算策略梯度 
        function [policy_loss, alpha_loss, policy_grads, alpha_grads] = calc_policy_grads(obj, ...
                policy_params, q1_params, q2_params, log_alpha, alpha, target_entropy, states)
            
            % 1. 重构策略网络
            policy_net = obj.create_policy_net();
            policy_net.Learnables = policy_params;
            
            % 2. 采样动作和对数概率
            [actions, log_probs] = obj.sample_action(policy_net, states);
            
            % 3. 重构Q1网络
            q1_net = obj.create_q_net();
            q1_net.Learnables = q1_params;
            current_input = [states; actions];
            q1 = forward(q1_net, current_input);
            
            % 4. 重构Q2网络
            q2_net = obj.create_q_net();
            q2_net.Learnables = q2_params;
            q2 = forward(q2_net, current_input);
            q = min(q1, q2);
            
            % 5. 策略损失           
            policy_loss = mean(alpha .* log_probs - q); %（最大化q）
            % 新逻辑：
            % 最小化 policy_loss = mean(q - alpha .* log_probs) → 等价于最大化 alpha*log_probs - q
            % 最终效果：策略会朝着"q 更大（奖励更高，适应值更低）"的方向优化
            % policy_loss = mean(q - alpha .* log_probs);
            policy_grads = dlgradient(policy_loss, policy_params);
            
            % 6. 温度系数损失
            alpha_loss = -mean(log_alpha .* (log_probs + target_entropy));
            alpha_grads = dlgradient(alpha_loss, log_alpha);
        end

        
        %% ========== 辅助方法 ==========
        function [actions, log_probs] = sample_action(obj, policy_net, states)
            output = forward(policy_net, states);
            mean = output(1:obj.action_dim, :);
            log_std = output(obj.action_dim+1:end, :);

            % 修复1：限制log_std范围，避免std=exp(log_std)→Inf
            log_std = max(min(log_std, 2), -2); % 限制log_std∈[-2,2]，std∈[0.135,7.389]
            std = exp(log_std);
            epsilon = randn(size(mean), 'like', mean);
            u = mean + std .* epsilon;
            actions = tanh(u);

            % 修复2：增大eps，避免log(0)
            safe_eps = 1e-6; % 从默认eps(2.2e-16)增大到1e-6
            log_prob = -0.5 * sum(log(2*pi) + 2*log_std + (u - mean).^2 ./ (std.^2 + safe_eps), 1);
            log_prob = log_prob - sum(log(1 - actions.^2 + safe_eps), 1);
            log_probs = log_prob;
        end

        function target_params = soft_update(obj, source_params, target_params)
            for i = 1:height(source_params)
                target_params.Value{i} = obj.tau * source_params.Value{i} + (1 - obj.tau) * target_params.Value{i};
            end
        end

        function opt_state = adaminit(obj, params, options)
            if isa(params, 'table')
                opt_state = struct();
                beta1 = options.Beta1;
                beta2 = options.Beta2;
                lr = options.LearningRate;
                
                for i = 1:height(params)
                    param_val = params.Value{i};
                    opt_state.(params.Layer{i}) = struct(...
                        'm', zeros(size(param_val), 'like', param_val), ...
                        'v', zeros(size(param_val), 'like', param_val), ...
                        'beta1', beta1, ...
                        'beta2', beta2, ...
                        'lr', lr, ...
                        't', 0);
                end
            elseif isa(params, 'dlarray')
                opt_state = struct(...
                    'm', zeros(size(params), 'like', params), ...
                    'v', zeros(size(params), 'like', params), ...
                    'beta1', options.Beta1, ...
                    'beta2', options.Beta2, ...
                    'lr', options.LearningRate, ...
                    't', 0);
            else
                error('不支持的参数类型：%s', class(params));
            end
        end


        %% 手动Adam更新（核心：绕过内置adamupdate，兼容所有版本）
        function [updated_params, updated_state] = adam_update_manual(obj, params, grads, state, lr, beta1, beta2, eps)
            if isa(params, 'table')
                updated_params = params;
                updated_state = state;
                
                for i = 1:height(params)
                    layer_name = params.Layer{i};
                    param = params.Value{i};
                    grad = grads.Value{i};
                    s = state.(layer_name);
                    
                    % 修复：梯度裁剪（限制梯度绝对值不超过10）
                    grad = max(min(grad, 10), -10);

                    % 更新一阶动量
                    s.m = beta1 * s.m + (1 - beta1) * grad;
                    % 更新二阶动量
                    s.v = beta2 * s.v + (1 - beta2) * grad.^2;
                    % 偏差校正
                    m_hat = s.m / (1 - beta1^(s.t + 1));
                    v_hat = s.v / (1 - beta2^(s.t + 1));
                    % 参数更新（新增：限制v_hat避免Inf）
                    v_hat = max(v_hat, 1e-8);
                    % 参数更新
                    param = param - lr * m_hat ./ (sqrt(v_hat) + eps);
                    
                    updated_params.Value{i} = param;
                    updated_state.(layer_name).m = s.m;
                    updated_state.(layer_name).v = s.v;
                    updated_state.(layer_name).t = s.t + 1;
                end
            elseif isa(params, 'dlarray')
                s = state;
                % 修复：梯度裁剪
                grads = max(min(grads, 10), -10);

                s.m = beta1 * s.m + (1 - beta1) * grads;
                s.v = beta2 * s.v + (1 - beta2) * grads.^2;
                m_hat = s.m / (1 - beta1^(s.t + 1));
                v_hat = s.v / (1 - beta2^(s.t + 1));
                % 修复：限制v_hat避免Inf
                v_hat = max(v_hat, 1e-8);

                updated_params = params - lr * m_hat ./ (sqrt(v_hat) + eps);
                s.t = s.t + 1;
                updated_state = s;
            else
                error('不支持的参数类型：%s', class(params));
            end
        end
    end


end
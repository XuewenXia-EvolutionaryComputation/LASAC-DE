function [use_fixed] = should_use_fixed(ACF, FDC, Slope, Entropy, progress)
    % 景观感知判断：是否切换固定参数    true：使用固定参数 F CR    false： 使用 SAC 自适应   

    %% Exploration vs Exploitation（由 Entropy 决定）: Entropy > 0.6 → Exploration（探索）;  Entropy < 0.3 → Exploitation（收敛）
    %% Gradient Reliability（由 FDC + Slope）: FDC < 0.3 且 Slope < 0.3 → 正确梯度; 否则 → 误导梯度
    %% Landscape Structure（由 ACF）: ACF > 0.7 → Smooth; ACF < 0.3 → Rugged

    %% State 1：Ideal Convergence（理想收敛）: Entropy ↓ + FDC ↓ + Slope ↓ + ACF ↑
    %% State 2：Premature Convergence（早熟收敛）: Entropy ↓ + FDC ↑ + Slope ↑
    %% State 3：Rugged Exploration（复杂探索）: Entropy ↑ + ACF ↓
    %% State 4：Smooth but Deceptive（平滑欺骗）: ACF ↑ + FDC ↑
    % 
    % if progress < 0.10
    %     use_fixed = true;       
    %     return;
    % end
    % 
    % %% ================= 老方法 ================= %
    % % 条件1：ACF：越接近 1 → 地形越平滑连续；越接近 0 → 地形越崎岖混乱
    % smooth_landscape = (ACF >= 0.3);  
    % % 条件2：FDC：越接近 1 → 越容易优化；越接近 0 → 越难优化    
    % correlated_landscape = (FDC <= 0.6);
    % % 条件3：Slop：越接近 0 → 梯度越好、越容易优化；越接近 1 → 梯度越差、越难优化   
    % slop_landscape = (Slope <= 0.6); % 绝对值越小 ≈ 地形越平 ≈ 越难优化. Slope 显著 < 0 最优（指向最优解）; Slope > 0 有欺骗性
    % % 条件4：entropy：越接近 0 → 越规律集中；越接近 1 → 越无序分散   
    % converged = (Entropy <= 0.6);
    % % 满足任一 → 固定参数   
    % use_fixed = (smooth_landscape + correlated_landscape + slop_landscape + converged) >= 1;

    if progress < 0.1  % 初期：先使用固定参数，避免随机种群导致误判
        use_fixed = true;
        return;
    else
        difficulty = 0.25*(1 - ACF) + 0.25*FDC + 0.25*Slope + 0.25*Entropy;
        % difficulty = 0.5*abs(0.5 - ACF) + 0.25*FDC + 0.25*Slope + 0.25*Entropy;
        use_fixed = difficulty < 0.55; return;   % 0.55
    end

    %% ================= 新方法 ================= %
    % true  = 使用固定 F/CR
    % false = 使用 SAC 生成 F/CR

    % 初期：先使用固定参数，避免随机种群导致误判
    % if progress < 0.10
    %     use_fixed = true;
    %     state = "early_fixed";
    %     return;
    % end
    % 
    % reliable_direction = (FDC > 0.60) && (Slope > 0.60);    
    % misleading_direction = (FDC < 0.35) || (Slope < 0.35);    
    % uncertain_direction = ~reliable_direction && ~misleading_direction;    
    % premature = (Entropy < 0.25) && misleading_direction;    
    % rugged = (ACF < 0.20) && (Entropy > 0.70) && misleading_direction;    
    % smooth_deceptive = (ACF > 0.70) && misleading_direction;
    % 
    % if reliable_direction
    %     use_fixed = true;
    %     state = "reliable_direction_fixed";
    % 
    % elseif premature
    %     use_fixed = false;
    %     state = "premature_convergence";
    % 
    % elseif rugged
    %     use_fixed = false;
    %     state = "rugged_exploration";
    % 
    % elseif smooth_deceptive
    %     use_fixed = false;
    %     state = "smooth_deceptive";
    % 
    % elseif uncertain_direction
    %     use_fixed = true;
    %     state = "uncertain_but_fixed";
    % 
    % else
    %     use_fixed = true;
    %     state = "normal_fixed";
    % end
    % 
    

    % --- Stage 1: Early exploration ---
    % if progress < 0.1  % 初期：先使用固定参数，避免随机种群导致误判
    %     use_fixed = true;
    %     return;
    % end

    % --- Stage 2: Exploitation 判断 ---
    % if Entropy < 0.01        
    %     % ✔ 正确收敛
    %     if FDC >= 0.6 && ACF >= 0.6  ||   FDC >= 0.6 && Slope >= 0.6
    %         use_fixed = true;
    % 
    %     % ❌ 错误收敛（局部最优）
    %     else
    %         use_fixed = false;
    %     end
    % 
    % else
    %     % --- Exploration 区域 ---        
    %     % ❌ Rugged（多峰/混乱）
    %     if FDC > 0.5 && ACF > 0.6 && Slope > 0.6 % ACF < 0.2
    %         use_fixed = true; %false;
    % 
    %     % % ✔ Smooth + 正确方向（接近单峰）
    %     % elseif ACF > 0.9 && FDC > 0.9 
    %     %     use_fixed = true;
    %     % 
    %     % % ❌ Smooth but deceptive（关键！）
    %     % elseif ACF >= 0.6 && FDC <= 0.4 
    %     %     use_fixed = false;
    % 
    %     % ❌ 不确定区域
    %     else
    %         use_fixed = false; % true;  %
    %     end
    % end
    % 


    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
    % % 处理由于种群完全收敛导致的占位符 0.5
    % % 当熵极低（完全收敛）且 FDC 或 Slope 为 0.5 时，将其修正为 1.0（完美相关）
    % if Entropy < 1e-6
    %     if abs(FDC - 0.5) < 1e-6
    %         FDC = 1.0;
    %     end
    %     if abs(Slope - 0.5) < 1e-6
    %         Slope = 1.0;
    %     end
    %     if abs(ACF - 0.5) < 1e-6
    %         ACF = 1.0;
    %     end
    % end
    % 
    % %% 2. 计算各指标对"简单问题"的支持度 (S_value ∈ [0,1])
    % S_ent   = max(0, 1 - Entropy / 0.2);          % 熵越低支持度越高
    % S_fdc   = max(0, (FDC - 0.4) / 0.5);          % FDC > 0.7 时接近 1
    % S_acf   = max(0, (ACF - 0.4) / 0.5);          % ACF > 0.7 时接近 1
    % S_slope = Slope^2;                            % 对高 Slope 敏感放大
    % 
    % % 情形1：种群已完全收敛（熵≈0）
    % if Entropy < 1e-5
    %     % 只要地形不是明显欺骗（FDC>0.4 且 Slope>0.4）→ 用固定参数
    %     % 注意：0.4 对应原始相关系数 -0.2，已非常宽松
    %     if FDC > 0.4 && Slope > 0.4
    %         use_fixed = true;
    %         % V_fixed = 0.8;   % 高置信度
    %     else
    %         % 收敛但相关性极差（如欺骗性地形）→ 启动SAC尝试跳出
    %         use_fixed = false;
    %         % V_fixed = 0.2;
    %     end
    %     return;
    % end
    % 
    % %% 3. 根据优化阶段计算综合支持度 V_fixed
    % if Entropy < 0.1   % 收敛后期：主要依赖 FDC 和 Slope
    %     V_fixed = (S_fdc + S_slope) / 2;
    % else               % 搜索阶段：加权融合多维特征
    %     % 权重: ACF 0.3, FDC 0.4, Slope 0.2, 1-Entropy 0.1
    %     V_fixed = 0.3 * S_acf + 0.4 * S_fdc + 0.2 * S_slope + 0.1 * (1 - S_ent);
    % end
    % 
    % % 确保置信度在 [0,1]
    % V_fixed = max(0, min(1, V_fixed));
    % 
    % %% 4. 最终决策
    % if V_fixed > 0.75
    %     use_fixed = true;   % 高置信度，使用固定参数
    % elseif V_fixed < 0.3
    %     use_fixed = false;  % 低置信度，使用 SAC
    % else
    %     % 中等置信度区域：可选用混合策略，这里保守采用 固定参数
    %     use_fixed = false;
    % end

end


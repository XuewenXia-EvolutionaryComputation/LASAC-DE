%% SAC-DE: Soft Actor-Critic assisted Differential Evolution
% 种群划分为多个子种群（每组3个个体），每类个体共享参数：
% 精英个体 -> F1, CR1
% 平凡个体 -> F2, CR2
% 劣质个体 -> F3, CR3
% SAC每隔interval代更新这6个参数，同时随机重划分子种群

clear; clc;  
%close all;
rand('state',sum(100*clock));

%% 1. 问题设置
D=10;
C=-100;
Xmax=100*ones(1,D);
Xmin=-100*ones(1,D);
Limits= [Xmin; Xmax];
fhd=str2func('cec17_func');
fbias=[100, 200, 300, 400, 500,...
       600, 700, 800, 900, 1000,...
       1100,1200,1300,1400,1500,...
       1600,1700,1800,1900,2000,...
       2100,2200,2300,2400,2500,...
       2600,2700,2800,2900,3000 ];

jingdu=0;

funset=[1:30];
max_runtimes = 5;  % 每个函数独立优化的次数
Overall_Results = zeros(max_runtimes, length(funset)); % 记录最终的结果：第 i 列为第 i 个函数多次得到的最优结果

for func_num =1:12  % 共 30 个函数 
    problem.nvars = D;                               % 变量维度
    problem.lb = Xmin;                               % -100 * ones(1, problem.nvars);       % 下界
    problem.ub = Xmax;                               % 100 * ones(1, problem.nvars);        % 上界
    steps_in_Episode = 1;                            % 每回合中种群进化的代数
    
    %% 2. DE参数
    DE.fhd = fhd;
    DE.func_num = func_num;
    DE.fbias = fbias;
    DE.group_num = 20;
    DE.group_size = 3;
    DE.nvars = D;
    DE.NP = DE.group_size*DE.group_num;              % 种群大小（必须是3的倍数）
    DE.maxgen = ceil(10000*D/DE.NP/steps_in_Episode);% 最大进化代数（可设为10000，这里为缩短演示）
    DE.stagnated = 0;                                % 种群连续停滞代数
    DE.maxStag = 2;                                  % 种群最大连续停滞代数，DE.stagnated > DE.maxStag 时重新随机分组
    DE.interval = 10;                                % 参数调整周期
    DE.regroup = 10;                                % 重划分周期
    DE.F_range =  [0.40, 0.60; ...
                   0.60, 0.80; ...
                   0.80, 1.00];   % F的取值范围:第一列为 F_elite, F_ordinary, F_inferior 的下限，第二行为上限
    DE.CR_range = [0.10, 0.50; ...
                   0.10, 0.50; ...
                   0.10, 0.50];   % CR的取值范围:第一列为 CR_elite, CR_ordinary, CR_inferior 的下限，第二行为上限
    
    FADE_F_elite = 0.5;    FADE_CR_elite = 0.1;        % 这三组参数是 FADE 中使用的，用来验证
    FADE_F_ordinary = 0.8; FADE_CR_ordinary = 0.5;
    FADE_F_inferior = 1.0; FADE_CR_inferior = 0.1;
    
    use_fixed_prev = false;

    %% 3. SAC智能体设置   
    action_dim = 6;                               % 3个F + 3个CR：前3维是F（F1/F2/F3），后3维是CR（CR1/CR2/CR3）
    state_dim = action_dim + 6;                   % 上一代的 action 个数，fdc_value; acf_value; slope; entropy; best_stag; progress(即 gen/Maxgen)
    state = zeros(state_dim, 1);     
    sac = SAC_Agent(state_dim, action_dim, DE.F_range, DE.CR_range);
    
    % 经验回放池
    buffer_size = ceil(DE.maxgen*0.10);           % 预计将前 10% 的代数直接使用静态参数，同时将相关经验存入 buffer
    buffer = ExperienceBuffer(buffer_size);         % 容量为：DE.maxgen
    batch_size = 2^round(log2(buffer_size/4));
    
    %% 4. 辅助存储
    best_history = zeros(DE.maxgen, 1);
    
    %% 5. 初始状态与动作
    % 初始化种群
    population = repmat(problem.lb, DE.NP, 1) + rand(DE.NP, problem.nvars) .*repmat(problem.ub - problem.lb, DE.NP, 1);
    fitness =(feval(fhd,population',func_num)-fbias(func_num))';
    [best_fitness, best_idx] = min(fitness);% 记录全局最优
    best_individual = population(best_idx, :);
    
    % 第一次子种群划分与分类
    subpopsID = reshape(randperm(DE.NP), [], 3);        % 随机划分，每组3个个体。subpopsID 第 i 行的3个值表示第 i 个子种群的3个的编号
    [class_labels, BMW_in_sub] = classify_individuals(population, fitness, subpopsID);
    % class_labels 大小为(NP,1): 其值为对应个体在所属子种群中的类别： 1-精英, 2-平凡, 3-劣质 
    
    % 获取初始状态
    gen = 0;
    best_stag=0;   % 最优解连续停滞代数
    best_imp = 0;  % 最优解连续进化代数
    stagnated = 0;
    
    pre_best_fitness = best_fitness;
    
    rnd_F_elite = DE.F_range(1,1) + rand*(DE.F_range(1,2)-DE.F_range(1,1));
    rnd_F_ordinary = DE.F_range(2,1) + rand*(DE.F_range(2,2)-DE.F_range(2,1));
    rnd_F_inferior = DE.F_range(3,1) + rand*(DE.F_range(3,2)-DE.F_range(3,1));
    rnd_CR_elite = DE.CR_range(1,1) + rand*(DE.CR_range(1,2)-DE.CR_range(1,1));
    rnd_CR_ordinary = DE.CR_range(2,1) + rand*(DE.CR_range(2,2)-DE.CR_range(2,1));
    rnd_CR_inferior = DE.CR_range(3,1) + rand*(DE.CR_range(3,2)-DE.CR_range(3,1));
    
    FCR = [rnd_F_elite; rnd_F_ordinary; rnd_F_inferior; rnd_CR_elite; rnd_CR_ordinary; rnd_CR_inferior];   
    state = calc_State(1, FCR, population, fitness, BMW_in_sub, best_stag, DE, problem); % 替换上面的

    action = sac.get_exploration_action(state);       % 初始随机探索
 
    % 记录上一个interval开始时的状态和动作，用于奖励计算
    pre_state = state;
    pre_action = action;
    rewarder = DELaggedReward(DE.maxgen, 3, false);  % false:最小化; true:最大化

    reward = 0;
    fprintf('预填充经验前，buffer.size()=%d\n', buffer.size());
    for gen = 1:buffer_size  % 预填充经验
        F2=max(0,0.5-(0.5)*gen/(DE.maxgen*2/3)); % 设置参数 F2
        [population, fitness, best_individua, best_fitness, BMW_in_sub, subBestImproved, globalBestImproved]...
            =StateUpdate_DE(fhd, func_num, fbias, Limits, population, fitness, BMW_in_sub, DE.F_range, DE.CR_range, pre_action, steps_in_Episode, F2);
        % ========== 每代都存储经验 ========== 
        if globalBestImproved            
            best_stag = 0;  
            best_imp = best_imp+1;
        else
            best_imp = 0;
            best_stag = best_stag+1;
        end

        state = calc_State(gen, pre_action, population, fitness, BMW_in_sub, best_stag, DE, problem); 

        % 获取双因子延迟奖励
        reward = rewarder.getReward(best_fitness, population, gen);
        buffer.add(pre_state, pre_action, reward, state, 0);  % 每代存储 1 条经验
        action = sac.get_exploration_action(state);       % 初始随机探索 action = 0.1 + 0.8 * rand(6,1);    
        pre_state = state;  % 更新pre_state   
        pre_action = action;% 更新pre_action
    end
    fprintf('预填充完成，最终buffer.size()=%d\n', buffer.size());  % 应输出20


    %% 6. 主进化循环
    for runtimes = 1:max_runtimes
        fprintf("\n==============func_num = %d, runtime = %d ================\n", func_num, runtimes)
        % ====================== Begin: 初始化 ===================== %
        % 初始化种群
        population = repmat(problem.lb, DE.NP, 1) + rand(DE.NP, problem.nvars) .*repmat(problem.ub - problem.lb, DE.NP, 1);
        fitness =(feval(fhd,population',func_num)-fbias(func_num))';
        [best_fitness, best_idx] = min(fitness);% 记录全局最优
        best_individual = population(best_idx, :);
        
        % 第一次子种群划分与分类
        subpopsID = reshape(randperm(DE.NP), [], 3);        % 随机划分，每组3个个体。subpopsID 第 i 行的3个值表示第 i 个子种群的3个的编号
        [class_labels, BMW_in_sub] = classify_individuals(population, fitness, subpopsID);
        
        % 获取初始状态
        gen = 1; best_stag=0; best_imp = 0; 
        DE.stagnated = 0;
        pre_best_fitness = best_fitness;
        FCR = [0.4+0.6*rand(3,1); 0.1+0.8*rand(3,1)];      
        state = calc_State(gen, pre_action, population, fitness, BMW_in_sub, best_stag, DE, problem); %
        action = sac.get_exploration_action(state);       % 初始随机探索

        % 记录上一个interval开始时的状态和动作，用于奖励计算
        pre_state = state;
        pre_action = action;

        usingSAC_count = 0;  % 调试用。记录使用 SAC 的次数。

        rewarder = DELaggedReward(DE.maxgen, 3, false);  % 最小化
        % ====================== End: 初始化 ======================= %

        % %%%% 以下为画图用
        % old = 1; new = 1;
        % yyy(old:new) = best_fitness;
        % old = new;
        
        for gen = 1:DE.maxgen
                  
            F2=max(0,0.5-(0.5)*gen/(DE.maxgen*2/3)); % 设置参数 F2
            [population, fitness, best_individua, best_fitness, BMW_in_sub, subBestImproved, globalBestImproved]...
                =StateUpdate_DE(fhd, func_num, fbias, Limits, population, fitness, BMW_in_sub, DE.F_range, DE.CR_range, pre_action, steps_in_Episode, F2);
            
            best_history(gen) = best_fitness;
            if globalBestImproved            
                best_stag = 0;  
                best_imp = best_imp+1;
            else
                best_imp = 0;
                best_stag = best_stag+1;
                DE.stagnated = DE.stagnated+1;
            end
        
            % ========== 每代都存储经验 ==========                   
            state = calc_State(gen, pre_action, population, fitness, BMW_in_sub, best_stag, DE, problem); %               
            reward = rewarder.getReward(best_fitness, population, gen);
            buffer.add(pre_state, pre_action, reward, state, 0);  % 每代存1条    

            % 每 interval 代训练SAC（经验足够时） ==========
            if mod(gen, DE.interval) == 0         
                sac.train(buffer, batch_size);    % 512    
            end

            %% ======================
            %% 景观感知自动模式切换。若景观较平滑、简单，则选用固定的合适的参数       
            FDC = state(1);    % FDC：越接近 1 → 越难优化；越接近 0 → 越容易优化  
            ACF = state(2);    % ACF：越接近 1 → 地形越平滑连续；越接近 0 → 地形越崎岖混乱         
            Slop = state(3);   % 越接近 0 → 梯度越好、越容易优化；越接近 1 → 梯度越差、越难优化
            Entropy = state(4);% 越接近 0 → 越规律集中；越接近 1 → 越无序分散
            progress = gen/DE.maxgen;
            use_fixed = should_use_fixed(ACF, FDC, Slop, Entropy, progress);  % 模式判断

            pre_state = state;  % 更新pre_state             
            
            if use_fixed                
                % ======================
                % 简单景观 → 固定最优参数
                % ======================
                rnd_F_elite = DE.F_range(1,1) + rand*(DE.F_range(1,2)-DE.F_range(1,1));
                rnd_F_ordinary = DE.F_range(2,1) + rand*(DE.F_range(2,2)-DE.F_range(2,1));
                rnd_F_inferior = DE.F_range(3,1) + rand*(DE.F_range(3,2)-DE.F_range(3,1));
                rnd_CR_elite = DE.CR_range(1,1) + rand*(DE.CR_range(1,2)-DE.CR_range(1,1));
                rnd_CR_ordinary = DE.CR_range(2,1) + rand*(DE.CR_range(2,2)-DE.CR_range(2,1));
                rnd_CR_inferior = DE.CR_range(3,1) + rand*(DE.CR_range(3,2)-DE.CR_range(3,1));
                pre_action = [rnd_F_elite; rnd_F_ordinary; rnd_F_inferior; rnd_CR_elite; rnd_CR_ordinary; rnd_CR_inferior];  % 测试用 ！！！
            else
                action = sac.get_action(state);                    
                pre_action = action;               % 更新pre_action
                usingSAC_count = usingSAC_count+1;
            end
            
        
            % 更新相关信息
            pre_best_fitness = best_fitness;     
           
            % 重划分子种群逻辑不变            
            if DE.stagnated>=DE.maxStag || mod(gen, DE.regroup) == 0  
                DE.stagnated=0;
                subpopsID = reshape(randperm(DE.NP), [], 3);       
                [class_labels, BMW_in_sub] = classify_individuals(population, fitness, subpopsID);
            end
        
        
            % 显示进度
            if mod(gen, 200) == 0
                obtain_F_elite = pre_action(1); obtain_F_ordinary = pre_action(2); obtain_F_inferior = pre_action(3);
                obtain_CR_elite = pre_action(4); obtain_CR_ordinary = pre_action(5); obtain_CR_inferior = pre_action(6);
                fprintf('============ ACF=%.4f, FDC=%.4f, Slop=%.4f, Entropy=%.4f, Difficulty = %.4f =============\n', ACF, FDC, Slop, Entropy, 0.25*(1-ACF) + 0.25*FDC + 0.25*Slop + 0.25*Entropy);
                fprintf('Gen %d, Best fitness: %.4e, reward = %.2f, F_elite=%.2f, CR_elite=%.2f, F_ordinary=%.2f, CR_ordinary=%.2f, F_inferior=%.2f, CR_inferior=%.2f, UsingSAC_count = %d\n', ...
                    gen, best_fitness, reward, obtain_F_elite, obtain_CR_elite, obtain_F_ordinary, obtain_CR_ordinary, obtain_F_inferior, obtain_CR_inferior, usingSAC_count);      
            end
    
            if best_fitness <= eps  % eps = 2.22e-16 
                fprintf('Gen %d, Best fitness: %.4e, UsingSAC_count = %d  =======================\n', gen, best_fitness, usingSAC_count);
                break;
            end
        end
        
        Overall_Results(runtimes, func_num) = best_fitness;
        SAC_UsageRatio(runtimes,func_num) = usingSAC_count/DE.maxgen;
        % fprintf("SAC使用占比：%.2f\n",usingSAC_count/DE.maxgen);   
       
        %%%% 以下为画图用
        % new = fitcount;
        % yyy(old:new) = gbestfit;   
        % old = new; 
        %%%%%%%%%%%%%%%%%%%%%%

    end
   

    Avg_SAC_UsageRatio(1,func_num) = mean(SAC_UsageRatio(:, func_num));
    fprintf('Function %d: AvgResult = %.2e, BestResult = %.2e, Std. = %.2e;  Avg_SAC_UsageRatio = %.2f%% \n', ...
        func_num, mean(Overall_Results(:, func_num)), min(Overall_Results(:, func_num)), std(Overall_Results(:, func_num)), 100*Avg_SAC_UsageRatio(1,func_num));
    fprintf("\n\n");
end

i=1;

% xlswrite('example.xlsx', Overall_Results); % 将数据写入example.xlsx文件的第一张工作表

%% 7. 结果可视化
% figure(1)
% hold on;
% xlabel('FEs','FontName','Times New Roman','FontSize',8);
% ylabel('Fitness','FontName','Times New Roman','FontSize',8);
% set(gca,'FontName','Times New Roman','FontSize',8)
% % title('Fitness');
% x=1:round(DE.maxgen/20):DE.maxgen;
% x(21)=DE.maxgen;
% 
% % plot(x,best_history(x),'-ko','MarkerFaceColor','k','MarkerSize',5);   % fixed-DE
% % plot(x,best_history(x),'--k^','MarkerFaceColor','r','MarkerSize',5);  % SAC-DE
% plot(x,best_history(x),':ks','MarkerFaceColor','b','MarkerSize',5);   % LASAC-DE
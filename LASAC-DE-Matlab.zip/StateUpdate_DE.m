function [pos, fit, gbest, gbestval, BMW_in_sub, subBestImproved, globalBestImproved]=StateUpdate_DE(fhd, func_num, fbias, lu, pos, fit, BMW_in_sub, F_range, CR_range, FCR, iters, F2)
                                                                 
    F_best = FCR(1); F_mid = FCR(2); F_worst = FCR(3); CR_best = FCR(4); CR_mid = FCR(5); CR_worst = FCR(6);
 
    group_num = size(BMW_in_sub, 1);   % 子种群的个数
    group_size = size(BMW_in_sub, 2);  % 子种群的大小，即每个子种群包含个体的数量
    
    ps = group_num*group_size;
    [gbestval_old, gbestID] = min(fit);
    gbest = pos(gbestID,:);
    D = length(gbest);
    subBestImproved = zeros(1,group_num);

    subBestval = fit(BMW_in_sub(:,1));  subBest = pos(BMW_in_sub(:,1),:);      % 每个子种群的最优解信息：适应值、解
    subMidval = fit(BMW_in_sub(:,2));   subMid = pos(BMW_in_sub(:,2),:);       % 每个子种群的中间解信息：适应值、解
    subWorstval = fit(BMW_in_sub(:,3)); subWorst = pos(BMW_in_sub(:,3),:);     % 每个子种群的最差解信息：适应值、解

    for iter = 1:iters         
        U = zeros(ps, D);   
        Ue = zeros(ps,1);
        for j=1:group_num   % 第 j 个子种群
            for k=1:3       % 第 k 个个体：1 -- 最优个体； 2 -- 中间个体； 3 -- 最差个体
                switch k
                    case 1
                        paraIndex = 5;   % 选择 DE 变异算子      
                        F = F_best; CR = CR_best;
                        F_Low = F_range(1,1);
                        F_Up = F_range(1,2);
                        parent = subBest; % 选择参与差分操作的父代群体                        
                    case 2
                        paraIndex=2;   % 选择 DE 变异算子% 已被改为：current-to-pbest/1   
                        F = F_mid; CR = CR_mid;
                        F_Low = F_range(2,1);
                        F_Up = F_range(2,2);
                        parent=[subMid;subBest];  % 选择参与差分操作的父代群体  
                    case 3
                        paraIndex=3;   % 选择 DE 变异算子         
                        F = F_worst; CR = CR_worst;
                        F_Low = F_range(3,1);
                        F_Up = F_range(3,2);
                        parent=[subWorst;subMid;subBest];  % 选择参与差分操作的父代群体
                end
                
                F_LU = [F_Low, F_Up];
                U(BMW_in_sub(j,k),:)= Breed_offspring(F_LU, pos(BMW_in_sub(j,k),:), gbest, subBest, subWorst, parent, lu, F, CR, F2, paraIndex); % F2 -> 0
                Ue(BMW_in_sub(j,k))=feval(fhd,U(BMW_in_sub(j,k),:)',func_num)-fbias(func_num);
            end
        end
    
        %============== 生成后代种群 pos 及其适应值 e ============= %
        pos=repmat((Ue<=fit),1,D).*U+repmat((Ue>fit),1,D).*pos;      % 利用贪婪法保留父代 pos 和试验向量 Ue 中的较优者
        fit=(Ue<=fit).*Ue+(Ue>fit).*fit;
    
        for i=1:group_num    % 更新每个子种群的最优解 subBest 及最差解 subWorst
            %%%%%%%%%%%%%%%%%%%%%%%
            [val, IX]=sort(fit(BMW_in_sub(i,:)),'ascend');
            BMW_in_sub(i,:)=BMW_in_sub(i,IX);                    % 根据排序后的结果更新 BMW_in_sub 及 pos 的信息
    
            if val(1)<subBestval(i)
                subBestImproved(i) = subBestImproved(i) + 1; % 若子种群最优解得到进化，则记录 +1                
            end
            subBestval(i)=val(1);
            subBest(i,:)=pos(BMW_in_sub(i,IX(1)),:);                 % 记录每个子种群的最优个体及其适应值    

            subMidval(i)=val(2);
            subMid(i,:)=pos(BMW_in_sub(i,IX(2)),:);                  % 记录每个子种群的中间个体及其适应值    

            subWorstval(i)=val(3);
            subWorst(i,:)=pos(BMW_in_sub(i,IX(3)),:);                % 记录每个子种群的最差个体及其适应值
        end
     
        [gbestval, gbestID]=min(fit);
        gbest=pos(gbestID(1),:);
    end

    globalBestImproved = 0;
    if gbestval < gbestval_old   % 种群最优得到进化
        globalBestImproved = 1;
    end
    

end



function [class_labels, BMW_in_sub] = classify_individuals(population, fitness, subpops)
    % 根据子种群划分，将每个子种群中的个体分类
    % class_labels: 每个个体的类别 (1-精英, 2-平凡, 3-劣质)
    % best_in_sub: 每个子种群中精英个体的索引
    % worst_in_sub: 每个子种群中劣质个体的索引
    NP = size(population, 1);
    class_labels = zeros(NP, 1);
    best_in_sub = zeros(size(subpops,1),1);
    mid_in_sub = zeros(size(subpops,1),1);
    worst_in_sub = zeros(size(subpops,1),1);
    
    for k = 1:size(subpops,1)
        idx = subpops(k,:);                      % 该子种群的3个个体索引
        [~, order] = sort(fitness(idx));         % 适应值升序（最小化问题）
        % order(1)是最好，order(3)是最差
        elite_idx = idx(order(1));
        ordinary_idx = idx(order(2));
        inferior_idx = idx(order(3));
        
        class_labels(elite_idx) = 1;
        class_labels(ordinary_idx) = 2;
        class_labels(inferior_idx) = 3;
        
        best_in_sub(k) = elite_idx;
        mid_in_sub(k) = ordinary_idx;
        worst_in_sub(k) = inferior_idx;
    end
    BMW_in_sub = [best_in_sub, mid_in_sub, worst_in_sub]; % 第 i 行从左至右依次为第 i 个子种群中 best, mid, worst 个体的编号
end
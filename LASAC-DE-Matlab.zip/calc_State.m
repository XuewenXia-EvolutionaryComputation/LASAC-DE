function state = calc_State(gen, FCR, pop, fitness, BMW_in_sub, best_stag, DE, problem)
                  
    % 功能：计算SAC-DE的8维最优state向量（无冗余、归一化、适配SAC训练）
    % 输入参数说明：
    %   pop:           DE种群矩阵 (N×D, N=种群规模, D=维度)
    %   fitness:       种群适应度向量 (N×1)
    %   f_opt:         理论最优适应度值
    %   gen:           当前进化代数
    %   MAX_GENERATION:最大进化代数
    %   stall_gen:     最优解连续停滞代数
    %   F_prev:        上一代使用的F值
    %   CR_prev:       上一代使用的CR值
    % 输出参数：
    %   state:         8维归一化state向量（SAC输入）
    %   其余:          原始景观指标（备用/分析用）

    F_elite = FCR(1);  F_mid = FCR(2);  F_worst = FCR(3);  
    CR_elite = FCR(4); CR_mid = FCR(5);  CR_worst = FCR(6);
    F_pre_norm = [F_elite;  F_mid;  F_worst];
    CR_pre_norm = [CR_elite; CR_mid;  CR_worst];
   
    %% -------------------------- 1. 初始化参数 --------------------------
    N = DE.NP;          % 种群规模
    D = DE.nvars;          % 问题维度
    epsilon = 1e-10;           % 数值稳定性阈值
    window_size = min(10, N);  % 局部窗口大小（局部ACF计算用，最终不加入state）

     %% -------------------------- 2. 计算核心景观指标（无冗余版） --------------------------
    
    [val, ix] = min(fitness);  
    elites = pop(BMW_in_sub(:,1),:); N_elites = length(elites);
    f_elites = fitness(BMW_in_sub(:,1));  
    f_opt = pop(ix,:);  % 最优个体

    % 2.1 FDC (Fitness-Distance Correlation) - 适应度-距离相关性. FDC原生范围[0,1]:接近0：景观平滑，搜索易收敛;接近1：景观反向，搜索难度极高
    [FDC] = calc_FDC(pop, fitness, f_opt, epsilon);  %  calc_FDC(elites, f_elites, f_opt, epsilon);  % 
    
    % 2.2 全局ACF (Auto-Correlation Function) - 自相关函数. ACF原生范围[0,1]:接近1：景观整体连续、平滑；接近0：景观整体波动剧烈、碎片化
    [ACF] = calc_ACF_nearest(pop, fitness);   %   calc_ACF_nearest(elites, f_elites);    % 
    % [ACF] = calc_ACF(elites, f_elites, epsilon);  % calc_ACF(pop, fitness, epsilon);   %
    
    % 2.3 景观趋势斜率 - 适应度随搜索方向的变化趋势. 斜率归一化到[-1,1]:接近-1：适应度随距离增大而减小（符合理想搜索景观）；接近1：适应度随距离增大而增大；接近0：无明显趋势
    [Slope] = calc_Slope(pop, f_opt, fitness, epsilon);  %  calc_Slope(elites, f_opt, f_elites, epsilon); % 
    
    % % 2.4 适应度熵 - 种群在适应值上的多样性. 熵归一化到[0,1]:数值越小，适应度分布越集中、景观越有规律；数值越大，适应度分布越分散、景观越无序
    % [Entropy] = calc_FitnessEntropy(fitness, N, epsilon);  %  calc_FitnessEntropy(f_elites, N_elites, epsilon);  % 
    
    % 2.5 距离熵 - 种群在空间上的多样性. 熵归一化到[0,1]:数值越小，个体分布越集中、景观越有规律；数值越大，个体分布越分散、景观越无序
    lb = -100; ub = 100;
    [Entropy] = calc_PopDiversity(pop, lb, ub, epsilon);  %  calc_PopDiversity(elites, lb, ub, epsilon);  % 

    %% -------------------------- 3. 指标归一化（SAC训练核心！） --------------------------
    % 3.1 核心指标归一化（统一到[-1,1]或[0,1]，消除数值范围差异）
    FDC_norm = FDC; %normalize_to_range(FDC, -1, 1, epsilon);     % FDC原生范围[-1,1]:接近-1：景观平滑，搜索易收敛;接近1：景观反向，搜索难度极高
    ACF_norm = ACF; %normalize_to_range(ACF, 0, 1, epsilon);        % ACF原生范围[0,1]:接近1：景观整体连续、平滑；接近-1：景观整体波动剧烈、碎片化
    Slope_norm = Slope; %normalize_to_range(slope, -1, 1, epsilon);   % 斜率归一化到[-1,1]:接近-1：适应度随距离增大而减小（符合理想搜索景观）；接近1：适应度随距离增大而增大；接近0：无明显趋势
    Entropy_norm = Entropy; %normalize_to_range(entropy, 0, 1, epsilon);% 熵归一化到[0,1]:数值越小，适应度分布越集中、景观越有规律；数值越大，适应度分布越分散、景观越无序
    
    % 3.2 停滞代数归一化（上限设为20，避免数值过大）
    best_stag_norm = min(best_stag / 20, 1.0);              % 停滞代数归一化到[0,1]
    
    % 3.3 进化进度（[0,1]）
    progress_norm = gen / DE.maxgen;


    %% -------------------------- 4. 构建最终8维state向量（无冗余！） --------------------------
    state = [
        FDC_norm;       % 维度1：FDC（欺骗性）
        ACF_norm;       % 维度2：全局ACF（平滑性）
        Slope_norm;     % 维度3：景观斜率（趋势）
        Entropy_norm;   % 维度4：适应度熵（多样性）
        best_stag_norm; % 维度5：停滞代数（关键信号）
        progress_norm;  % 维度6：进化进度（阶段）
        F_pre_norm;    % 维度7-9：上一代F（必加！动作记忆）
        CR_pre_norm    % 维度10-12：上一代CR（必加！动作记忆）
    ];
      
end


%% -------------------------- 内部子函数：指标计算（核心） --------------------------
    %% ===== 子函数1：计算FDC =====
    function [fdc] = calc_FDC(pop, fitness, f_opt, epsilon)
        % 计算每个个体到最优解的欧氏距离。越接近 1 → 越难优化；越接近 0 → 越容易优化
        pop_opt = repmat(f_opt, size(pop,1), 1); % 最优解位置矩阵
        distances = sqrt(sum((pop - pop_opt).^2, 2));
        distances(distances < epsilon) = epsilon; % 避免除0
        
        % 计算FDC（皮尔逊相关系数）       
        [r, ~] = corrcoef(distances, fitness);
        fdc = r(1,2);

        if any(isnan(fitness)) || any(isinf(fitness)) || std(distances) < epsilon
            fdc = 0.5;
        elseif isnan(fdc)
            fdc = 0.5;
        end
        fdc = (fdc+1)/2;     
    end


    %% ===== 子函数2：计算全局ACF =====
    function [acf] = calc_ACF(pop, fitness, epsilon)
        % 基于种群位置排序计算自相关. 越接近 1 → 地形越平滑连续；越接近 0 → 地形越崎岖混乱
        [~, idx] = sort(sum(pop, 2)); % 按位置求和排序
        fitness_sorted = fitness(idx);
        
        % 一阶自相关
        acf = corrcoef(fitness_sorted(1:end-1), fitness_sorted(2:end));
        acf = acf(1,2);

        if any(isnan(fitness)) || std(fitness_sorted) < epsilon
            acf = 0.5;
        elseif isnan(acf)
            acf = 0.5;
        end        
        acf = max(min(acf, 1.0), 0.0);
        acf = (acf + 1) / 2;              % 映射到 [0,1]       
    end


    function acf = calc_ACF_nearest(pop, fitness)
        % pop: N×D 矩阵，N个个体，D维
        % fitness: N×1 向量
        N = size(pop, 1);
        if N < 4
            acf = 0.5;  % 种群太小，返回中性值
            return;
        end
        
        % 步骤1：使用广播计算欧氏距离矩阵（纯 MATLAB）
        % 计算平方和：|x-y|^2 = x^2 + y^2 - 2xy
        sq = sum(pop.^2, 2);
        Dmat = -2 * (pop * pop') + sq + sq';  % 平方距离矩阵
        Dmat(1:N+1:end) = inf;                 % 自身距离设为无穷
       
        % 对于每个点，找到最近邻（排除自身）
        [~, nearest_idx] = min(Dmat, [], 2);
        
        % 构建相邻适应度对
        f1 = fitness;
        f2 = fitness(nearest_idx);
        
        % 计算自相关（皮尔逊相关系数）
        acf = corrcoef(f1, f2);
        acf = acf(1,2);
        
        % 处理异常值
        if isnan(acf) || std(fitness) < 1e-8
            acf = 0.5;   % 平坦地形视为中性（或可根据需求设为1）
        end
        acf = max(min(acf, 1.0), -1.0);
        acf = (acf + 1) / 2;              % 映射到 [0,1]
    end


    %% ===== 子函数3：计算景观斜率 =====
    function [sl] = calc_Slope(pop, f_opt, fitness, epsilon)
              
        c = mean(pop,1);  %c = mean(pop,1);
        d = sqrt(sum((pop - c).^2,2));    
        if std(d) < epsilon || std(fitness) < epsilon
            sl = 0.5;
            return;
        end
    
        R = corrcoef(d, fitness);
        sl = R(1,2);
    
        if isnan(sl)
            sl = 0.5;
        end
    
        sl = (sl+1)/2;    
    end


    %% ===== 子函数4：计算适应度熵 =====
    function [ent] = calc_FitnessEntropy(fitness, N, epsilon)
        % 越接近 0 → 越规律集中；越接近 1 → 越无序分散
        fmin = min(fitness);
        fmax = max(fitness);
        if fmax-fmin < epsilon
            ent = 0.0; return;
        end
        fn = (fitness-fmin)/(fmax-fmin+epsilon);
        prob = fn / (sum(fn)+epsilon);
        ent = -sum( prob .* log(prob+epsilon) );

        if any(isnan(fitness)) || any(isinf(fitness))
            ent = 0.5;
        elseif isnan(ent)
            ent = 0.5;
        end
        ent = ent / log(N+epsilon);

    end
 
 
    %% ===== 子函数5：计算种群多样性 =====
    function div = calc_PopDiversity(pop, lb, ub, epsilon)

        range = ub - lb;
        range(range < epsilon) = epsilon;
    
        div_per_dim = std(pop, 0, 1) ./ range;
        div = mean(div_per_dim);
    
        div = max(min(div, 1), 0);
    end

